import requests

def get_request(path, params):
    api_key = '83d234ab35604f9089f1a85ee34f7f5d'
    url = f"https://api.spoonacular.com{path}"
    headers = { "Content-Type": "application/json" }
    params["apiKey"] = api_key
    response = requests.get(url, headers=headers, params=params)
    return response.json()

def find_by_nutrients(min_carbs, max_carbs, min_protein, max_protein, number=2):
    path = "/recipes/findByNutrients/"
    params = {
        "minCarbs": min_carbs,
        "maxCarbs": max_carbs,
        "minProtein": min_protein,
        "maxProtein": max_protein,
        "number": 2,
    }
    return get_request(path, params)

print(find_by_nutrients(1,2,3,4))