import os
import json
import requests
import urllib.parse

from cs50 import SQL
from flask import Flask, flash, jsonify, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash
from datetime import datetime
from delete_me import find_by_nutrients

from helpers import find_by_nutrients, get_random, login_required, apology

#confiqure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

db = SQL("sqlite:///project.db")

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)


@app.route("/")
def index():
    """Show home page"""

    return render_template("index.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username",
            username=request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")




@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        username = request.form.get("username")
        password = request.form.get("password")
        confirm_password = request.form.get("confirm password")

        # Ensure username was submitted
        if not username:
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not password:
            return apology("must provide password", 403)

        #Check to see if confirmation password exsists & matches
        elif not confirm_password or confirm_password != password:
            return apology("passwords do not match", 403)

        #query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username",username=username)

        # Ensure username exists and password is correct
        if len(rows) == 0:
            #hash password
            hash = generate_password_hash(password)
            db.execute("INSERT INTO users (username, hash) VALUES (:username, :hash)", username=username, hash=hash)
        else:
            return apology("username is taken", 403)

        flash("you have registered a new account")

        # Redirect user to home page
        return redirect("/")

    #user reached route via GET (as by clicking link or via redirect)
    else:
        return render_template("register.html")



@app.route("/change_password", methods=["GET", "POST"])
@login_required
def change_password():
    """change the password of the current user"""
    if request.method == "POST":
        #current user
        user_id = session["user_id"]

        password = request.form.get("password")
        confirm_password = request.form.get("confirm password")

        # Ensure password was submitted
        if not password:
            return apology("must provide password", 403)

        #Check to see if confirmation password exsists & matches
        elif not confirm_password or confirm_password != password:
            return apology("passwords do not match", 403)

        #query for username
        rows = db.execute("SELECT username FROM users WHERE id = :id", id = user_id)

        if len(rows) == 1:
            #re-hash password
            hash = generate_password_hash(password)
            db.execute("UPDATE users SET hash = :hash WHERE id = :id", hash=hash, id=user_id)

            flash("you have successfully changed your password")
            return redirect("/")

        else:
            return apology("please try again", 403)

    else:
        return render_template("change_password.html")




@app.route("/recipes", methods=["GET", "POST"])
def recipes():

    if request.method == "POST":

        min_carbs = request.form.get("minCarbs", 10, type=int)
        max_carbs = request.form.get("maxCarbs", 100, type=int)
        min_protein = request.form.get("minProtein", 10, type=int)
        max_protein = request.form.get("maxProtein", 100, type=int)
        min_calories = request.form.get("minCalories", 50, type=int)
        max_calories = request.form.get("maxCalories", 800, type=int)
        min_fat = request.form.get("minFat", 1, type=int)
        max_fat = request.form.get("maxFat", 100, type=int)

        r = find_by_nutrients(min_carbs, max_carbs, min_protein, max_protein, min_calories, max_calories, min_fat, max_fat)

        return render_template("recipes_final.html", r=r)
    else:
        return render_template("recipes.html")



@app.route("/random", methods=["GET", "POST"])
def random():

    if request.method == "POST":

        tags_r = request.form.get("tags", None, type=str)

        r = get_random(tags_r)

        return render_template("random_final.html", r=r["recipes"])
    else:
        return render_template("random.html")



@app.route("/save_recipe", methods=["GET", "POST"])
@login_required
def save_recipe():

    if request.method == "POST":
        user_id = session["user_id"]

        title = request.form.get("title")
        calories = request.form.get("calories")
        carbs = request.form.get("carbs")
        protein = request.form.get("protein")
        fat = request.form.get("fat")
        db.execute("INSERT INTO history (id, title, calories, carbs, protein, fat, date) VALUES (:id, :title, :calories, :carbs, :protein, :fat, :date)", id=user_id, title=title, calories=calories, carbs=carbs, protein=protein, fat=fat, date=datetime.now())
        flash("Recipe Has Been Saved!!!")
        return render_template("recipes.html")
    else:
        return render_template("recipes_final.html")



@app.route("/information", methods=["GET", "POST"])
def information(id):

    id = request.form.get("id")
    url = f"https://api.spoonacular.com/recipes/{id}/information?includeNutrition=false&apiKey=83d234ab35604f9089f1a85ee34f7f5d"
    headers = { "Content-Type": "application/json" }
    response = requests.get(url, headers=headers)
    return response.json()


@app.route("/history")
@login_required
def history():
    """Show history of transactions"""
    rows = db.execute("SELECT * FROM history WHERE id = :id", id=session["user_id"])
    return render_template("history.html", history_r=rows)